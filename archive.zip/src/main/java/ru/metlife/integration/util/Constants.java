package ru.metlife.integration.util;

public class Constants {

  public static final String FILE_EXTENSION_XLS = "xls";
  public static final String FILE_EXTENSION_XLSX = "xlsx";

  public static final int FI_LETTER_STATUS = 17;

  public static final String DELIVERY_STATUS_COMPLETED = "COMPLETED";
}
